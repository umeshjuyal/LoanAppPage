// for Captacha 
function Captcha(){
  var alpha = new Array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
  'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z', 
      '0','1','2','3','4','5','6','7','8','9');
  var i;
  for (i=0;i<6;i++){
    //Math. random() function returns a floating-point 
    // in the range 0 to less than 1

    //Math.floor() rounds a number DOWN to the nearest integer:
      var a = alpha[Math.floor(Math.random() * alpha.length)];
      var b = alpha[Math.floor(Math.random() * alpha.length)];
      var c = alpha[Math.floor(Math.random() * alpha.length)];
      var d = alpha[Math.floor(Math.random() * alpha.length)];
      var e = alpha[Math.floor(Math.random() * alpha.length)];
      var f = alpha[Math.floor(Math.random() * alpha.length)];
      var g = alpha[Math.floor(Math.random() * alpha.length)];
    }
      var code = a + ' ' + b + ' ' + ' ' + c + ' ' + d + ' ' + e + ' '+ f + ' ' + g;
      //innerHTML property is part of the Document Object Model
      document.getElementById("mainCaptcha").innerHTML = code
  document.getElementById("mainCaptcha").value = code
    }

    //Create a function
    //to validate the captcha
function ValidateCaptcha(){
  var string1 = removeSpaces(document.getElementById('mainCaptcha').value);
  var string2 = removeSpaces(document.getElementById('txtInput').value);
  if (string1 == string2){
      return true;
  }
  else{        
       return false;
  }
}
//function for remove spaces

function removeSpaces(string){
  return string.split(' ').join('');
}




// function form data

function getData(){

  //gettting the values
  var email = document.getElementById("email").value;
  var name= document.getElementById("name").value; 
  var pan= document.getElementById("pan").value; 
  var loan_money= document.getElementById("loan_amount").value; 
  //saving the values in local storage
  localStorage.setItem("txtValue", email);
  localStorage.setItem("txtValue1", name);
  localStorage.setItem("txtValue2", pan);
  localStorage.setItem("txtValue3", loan_money);   
  document.write("form sucessfully ");
}

function myfunc(){
  var x = document.getElementById("mySubmit").formTarget;
}





  //Name Validation
  function allLetter(inputtxt){
 var letters = /^[a-zA-Z -]*$/;
 if(inputtxt.value.match(letters)){
    return true;
   }
 else {
   alert("Not Correct Name");
   return false;
   }
}



//for Email Validation
 function validateEmail(inputText){
 var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(inputText.value.match(mailformat)){
alert("Valid email address!");
document.form1.text1.focus();
return true;
}
else{
alert("You have entered an invalid email address!");
document.form1.text1.focus();
return false;
}
}



// for Pan Card validation
function pan_validate(pan) {
var regpan = /^([A-Z]){5}([0-9]){4}([A-Z]){1}?$/;
if (regpan.test(pan) == false) {
  document.getElementById("status").innerHTML = "PAN Number Not Valid";
} 
else {
  alert("Pan No Valid");
  document.getElementById("status").innerHTML = "";

}
}


// for Loan Amount Validation
var a = ['','one ','two ','three ','four ', 'five ','six ','seven ','eight ','nine ','ten ','eleven ','twelve ','thirteen ','fourteen ','fifteen ','sixteen ','seventeen ','eighteen ','nineteen '];
var b = ['', '', 'twenty','thirty','forty','fifty', 'sixty','seventy','eighty','ninety'];

function inWords (num) {
  if ((num = num.toString()).length > 9) return 'overflow';
  n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
  if (!n) return; var str = '';
  str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore ' : '';
  str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'lakh ' : '';
  str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand ' : '';
  str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
  str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'only ' : '';
  return str;
}

document.getElementById('number').onkeyup = function () {
  document.getElementById('words').innerHTML = inWords(document.getElementById('number').value);
};
